package DBMS;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import org.junit.Test;

public class DBApp {
	static int dataPageSize = Page.getMaxRecords();

	public static void createTable(String name, String[] cols) {
		Table t = new Table(name, cols);
		t.addTrace("Table created name:" + name + ", columnsNames:"
				+ Arrays.toString(cols));
		FileManager.storeTable(name, t);
	}

	public static void insert(String tableName, String[] record) {
		long startTime = System.currentTimeMillis();

		// Load the table from disk
		Table table = FileManager.loadTable(tableName);
		if (table == null) {
			System.err.println("Insert failed: Table " + tableName
					+ " does not exist");
			return;
		}

		// Validate record length matches table columns
		if (record.length != table.getCols().length) {
			throw new IllegalArgumentException(
					"Record length doesn't match table columns");
		}

		// Get the last page or create a new one if needed
		int pageNumber;
		Page lastPage;

		if (table.getPages().isEmpty()) {
			// No pages exist yet - create first page
			lastPage = new Page();
			pageNumber = 0;
			table.getPages().add(lastPage);
		} else {
			// Get the last page
			pageNumber = table.getPages().size() - 1;
			lastPage = table.getPages().get(pageNumber);

			// Check if last page is full
			if (lastPage.getRecords().size() >= dataPageSize) {
				// to store the full page before creating a new one
				FileManager.storeTablePage(tableName, pageNumber, lastPage);

				// Create a new page
				lastPage = new Page();
				pageNumber++;
				table.getPages().add(lastPage);
			}
		}

		// Insert the record into the page
		lastPage.getRecords().add(record);

		// Store the updated page
		FileManager.storeTablePage(tableName, pageNumber, lastPage);

		// Update and store the table metadata
		long endTime = System.currentTimeMillis();
		long executionTime = endTime - startTime;

		// Add to trace log with detailed information
		table.addTrace("Inserted: " + Arrays.toString(record)
				+ ", at page number: " + pageNumber + ", execution time (ms): "
				+ executionTime);

		// Store the updated table
		FileManager.storeTable(tableName, table);
	}

	public static ArrayList<String[]> select(String tableName) {
		long start = System.currentTimeMillis();
		Table t = FileManager.loadTable(tableName);
		ArrayList<String[]> result = new ArrayList<>();

		if (t == null)
			return result;

		int NumberOfPages = t.getPages().size();
		int recordCount = 0;

		for (int i = 0; i < NumberOfPages; i++) {
			Page p = t.getPages().get(i);
			recordCount += p.getRecords().size();
			result.addAll(p.getRecords());
		}

		long end = System.currentTimeMillis();
		long duration = end - start;

		String traceEntry = "Select all pages:" + NumberOfPages + ", records:"
				+ recordCount + ", execution time (mil):" + duration;

		t.addTrace(traceEntry);

		/*
		 * ///old t.addTrace("Select all pages:" + NumberOfPages + ", records:"
		 * + recordCount + ", execution time (mil):" + duration);
		 */

		FileManager.storeTable(tableName, t);
		return result;
	}

	public static ArrayList<String[]> select(String tableName, String[] cols,
			String[] vals) {
		long start = System.currentTimeMillis();

		Table t = FileManager.loadTable(tableName);
		ArrayList<String[]> result = new ArrayList<>();
		if (t == null)
			return result;

		ArrayList<String> conditionColumns = new ArrayList<>();
		for (int i = 0; i < cols.length; i++) {
			conditionColumns.add(cols[i]);
		}

		// ArrayList<String[]> matchedRecords = new ArrayList<>();
		// ArrayList<String> matchedPages = new ArrayList<>();

		int pages = t.getPages().size();
		int totalRecords = 0;
		ArrayList<String> recordsPerPageList = new ArrayList<>();

		for (int i = 0; i < pages; i++) {
			Page p = t.getPages().get(i);
			totalRecords += p.getRecords().size(); // Count all records
			int matchedCount = 0;

			for (int j = 0; j < p.getRecords().size(); j++) {
				String[] record = p.getRecords().get(j);
				boolean match = true;

				for (int k = 0; k < cols.length; k++) {
					String col = cols[k];
					String val = vals[k];
					int colIndex = Arrays.asList(t.getCols()).indexOf(col);
					if (colIndex == -1 || !record[colIndex].equals(val)) {
						match = false;
						break;
					}
				}

				if (match) {
					result.add(record);
					matchedCount++;
					// matchedPages.add("[" + i + ", " + j + "]");
				}
			}
			if (matchedCount > 0) {
				recordsPerPageList.add("[" + i + ", " + matchedCount + "]");
			}
		}
		long end = System.currentTimeMillis();
		// int NumberOfPages = pages;
		int recordCount = result.size();
		String recordsPerPage = "[" + String.join(", ", recordsPerPageList)
				+ "]";
		// Combine into one trace entry
		// String traceEntry = "Select condition:[" + String.join(", ", cols) +
		// "]->[" +
		// String.join(", ", vals) + "], Records per page:" + recordsPerPage +
		// ", records:" + result.size()+"," + "\n"+ "execution time (mil):" +
		// (end - start) +
		// "\nPages Count: " + pages + ", Records Count: " + totalRecords ;
		String traceEntry = "Select condition:[" + String.join(", ", cols)
				+ "]->[" + String.join(", ", vals) + "], Records per page:"
				+ recordsPerPage + ", records:" + recordCount
				+ ", execution time (mil):" + (end - start);
		t.addTrace(traceEntry);
		/*
		 * t.addTrace("Select condition:[" + String.join(", ", cols) + "]->[" +
		 * String.join(", ", vals) + "], Records per page:" + matchedPages +
		 * ", records:" + result.size() + ", \nexecution time (mil):" + (end -
		 * start)); t.addTrace("Pages Count: " + NumberOfPages +
		 * ", Records Count: " + recordCount);
		 */
		FileManager.storeTable(tableName, t);

		return result;
	}

	public static ArrayList<String[]> select(String tableName, int pageNumber,
			int recordNumber) {
		long start = System.currentTimeMillis();
		ArrayList<String[]> result = new ArrayList<>();
		Table t = FileManager.loadTable(tableName);

		if (t == null)
			return result;
		if (pageNumber < 0 || pageNumber >= t.getPages().size())
			return result;

		Page p = t.getPages().get(pageNumber);
		if (p == null || recordNumber < 0
				|| recordNumber >= p.getRecords().size())
			return result;

		String[] record = p.getRecords().get(recordNumber);
		result.add(record);

		long end = System.currentTimeMillis();
		long duration = end - start;

		// Combine into one trace entry
		String traceEntry = "Select pointer page:" + pageNumber + ", record:"
				+ recordNumber
				+ ", total output count:1, execution time (mil):" + duration;
		t.addTrace(traceEntry);
		/*
		 * t.addTrace("Select pointer page:" + pageNumber + ", record:" +
		 * recordNumber + ", total output count:1, execution time (mil):" +
		 * duration);
		 */
		FileManager.storeTable(tableName, t);
		return result;
	}

	public static String getFullTrace(String tableName) {
		Table t = FileManager.loadTable(tableName);
		return t != null ? t.getFullTrace() : "";

	}

	public static String getLastTrace(String tableName) {
		Table t = FileManager.loadTable(tableName);
		return t != null ? t.getLastTrace() : "";
	}

	public static void main(String[] args) throws IOException {
		String[] cols = { "id", "name", "major", "semester", "gpa" };
		createTable("student", cols);
		String[] r1 = { "1", "stud1", "CS", "5", "0.9" };
		insert("student", r1);
		String[] r2 = { "2", "stud2", "BI", "7", "1.2" };
		insert("student", r2);
		String[] r3 = { "3", "stud3", "CS", "2", "2.4" };
		insert("student", r3);
		String[] r4 = { "4", "stud4", "DMET", "9", "1.2" };
		insert("student", r4);
		String[] r5 = { "5", "stud5", "BI", "4", "3.5" };
		insert("student", r5);
		System.out.println("Output of selecting the whole table content:");
		ArrayList<String[]> result1 = select("student");
		for (String[] array : result1) {
			for (String str : array) {
				System.out.print(str + " ");
			}
			System.out.println();
		}

		System.out.println("--------------------------------");
		System.out.println("Output of selecting the output by position:");
		ArrayList<String[]> result2 = select("student", 1, 1);
		for (String[] array : result2) {
			for (String str : array) {
				System.out.print(str + " ");
			}
			System.out.println();
		}

		System.out.println("--------------------------------");
		System.out
				.println("Output of selecting the output by column condition:");
		ArrayList<String[]> result3 = select("student", new String[] { "gpa" },
				new String[] { "1.2" });
		for (String[] array : result3) {
			for (String str : array) {
				System.out.print(str + " ");
			}
			System.out.println();
		}
		System.out.println("--------------------------------");
		System.out.println("Full Trace of the table:");
		System.out.println(getFullTrace("student"));
		System.out.println("--------------------------------");
		System.out.println("Last Trace of the table:");
		System.out.println(getLastTrace("student"));
		System.out.println("--------------------------------");
		System.out.println("The trace of the Tables Folder:");
		System.out.println(FileManager.trace());
		FileManager.reset();
		System.out.println("--------------------------------");
		System.out.println("The trace of the Tables Folder after resetting:");
		System.out.println(FileManager.trace());
	}

}
