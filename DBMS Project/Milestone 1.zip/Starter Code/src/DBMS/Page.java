package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Page implements Serializable {
    private List<String[]> records;
    private static final int MAX_RECORDS = 2;  // You can use a configurable value here

    public List<String[]> getRecords() {
		return records;
	}

	public void setRecords(List<String[]> records) {
		this.records = records;
	}

	public static int getMaxRecords() {
		return MAX_RECORDS;
	}

	public Page() {
        records = new ArrayList<>();
    }

    // Insert a record into the page
    public boolean insertRecord(String[] record) {
        if (records.size() < MAX_RECORDS) {
            records.add(record);
            return true;
        }
        return false;  // Page is full
    }

    // Check if the page is full
    public boolean isFull() {
        return records.size() >= MAX_RECORDS;
    }

    // Optionally, add more methods to manage pages, like removing a record or printing the page
}
