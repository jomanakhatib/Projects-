package DBMS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Table implements Serializable {
    private String TableName;
    private String[] Cols;
    private List<Page> pages;  // Changed to handle multiple pages
    //private List<String> trace;
    private ArrayList<String> traceLog;


    public Table(String tableName, String[] cols) {
    	TableName = tableName;
    	Cols = cols;
    	pages = new ArrayList<>();
    	//trace = new ArrayList<>();
    	this.traceLog = new ArrayList<>();
    	
    }
    
    
    public String getTableName() {
		return TableName;
	}

	public void setTableName(String tableName) {
		TableName = tableName;
	}

	public String[] getCols() {
		return Cols;
	}

	public void setCols(String[] cols) {
		Cols = cols;
	}

	public List<Page> getPages() {
		return pages;
	}

	public void setPages(List<Page> pages) {
		this.pages = pages;
	}

	public void insert(String[] record) {
	    if (record.length != Cols.length) return;

	    if (pages.isEmpty() || pages.get(pages.size() - 1).isFull()) {
	        pages.add(new Page());
	    }

	    pages.get(pages.size() - 1).insertRecord(record);
	}

/*	public void  insert(String[] record) {
	    if (record.length != Cols.length) return;

	    if (pages.isEmpty()) {
	        Page newPage = new Page();
	        pages.add(newPage);
	    }
	    
	    
	    Page lastPage = pages.get(pages.size() - 1);
	    if (lastPage.isFull()) {
	        Page newPage = new Page();
	        pages.add(newPage);
	        lastPage = newPage;
	    }
	    
	    lastPage.insertRecord(record);
        return ;
	}
*/

    
    /*public void addTrace(String traceEntry) {
        if (this.trace.size() >= 100) {
            this.trace.remove(0); // drop the oldest
        }
    	trace.add(traceEntry);
    }*/
	public void addTrace(String entry) {
        traceLog.add(entry);
    }
    /*public String getFullTrace() {
        int pagesCount = this.pages.size();
        int recordsCount = 0;
        for (Page p : this.pages) {
            recordsCount += p.getRecords().size();
        }
    	String traceRes= String.join("\n", trace);
        return traceRes + "\nPages Count: " + pagesCount + ", Records Count: " + recordsCount;

    }

    public String getLastTrace() {
        if (trace.isEmpty()) return "";
        return trace.get(trace.size() - 1);
    }*/
	public String getLastTrace() {
        return traceLog.isEmpty() ? "" : traceLog.get(traceLog.size() - 1);
    }

    public String getFullTrace() {
        StringBuilder sb = new StringBuilder();
        for (String entry : traceLog) {
            sb.append(entry).append(" \n");
        }

        // Append the required line
        sb.append("Pages Count: ").append(pages.size())
          .append(", Records Count: ").append(getTotalRecordCount());

        return sb.toString().trim(); // trim to avoid trailing newline
    }

    private int getTotalRecordCount() {
        int count = 0;
        for (Page p : pages) {
            count += p.getRecords().size();
        }
        return count;
    }

}
